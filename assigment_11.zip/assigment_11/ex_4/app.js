// app.js
new Vue({
    el: '#app',
    data: {
      username: '',
      email: '',
      password: '',
      errors: {
        username: '',
        email: '',
        password: '',
      },
    },
    computed: {
      hasErrors() {
        return Object.values(this.errors).some(error => error !== '');
      },
    },
    methods: {
      submitForm() {
        // Perform form submission logic
        // You can access the form data using this.username, this.email, and this.password
        // Validate the form fields and display error messages if necessary
        this.validateForm();
        if (!this.hasErrors) {
          // Submit the form or perform further actions
          console.log('Form submitted!');
        }
      },
      validateForm() {
        this.errors.username = this.username ? '' : 'Username is required.';
        this.errors.email = this.validateEmail() ? '' : 'Invalid email address.';
        this.errors.password = this.validatePassword() ? '' : 'Password must have a minimum length of 6 characters.';
      },
      validateEmail() {
        // Basic email validation regex pattern
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(this.email);
      },
      validatePassword() {
        return this.password.length >= 6;
      },
    },
  });