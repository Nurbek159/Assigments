// app.js
new Vue({
    el: '#app',
    data: {
      tasks: [
        { title: 'Task 1', completed: false },
        { title: 'Task 2', completed: true },
        { title: 'Task 3', completed: false }
      ],
      newTask: ''
    },
    methods: {
      toggleTaskStatus(index) {
        this.tasks[index].completed = !this.tasks[index].completed;
      },
      addTask() {
        if (this.newTask) {
          this.tasks.push({ title: this.newTask, completed: false });
          this.newTask = '';
        }
      }
    }
  });